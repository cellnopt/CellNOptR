#
#  This file is part of the CNO software
#
#  Copyright (c) 2011-2012 - EBI
#
#  File author(s): CNO developers (cno-dev@ebi.ac.uk)
#
#  Distributed under the GPLv2 License.
#  See accompanying file LICENSE.txt or copy at
#      http://www.gnu.org/licenses/gpl-2.0.html
#
#  CNO website: http://www.ebi.ac.uk/saezrodriguez/software.html
#
##############################################################################
# $Id: MIinference.R 853 2012-03-28 15:09:06Z cokelaer $
MIinference <-
function(CNOlist, method="ARACNE", PKNgraph=NULL, filename="ARACNE"){
  
  library(minet)

  
  valueStimuli<-CNOlist$valueStimuli
  colnames(valueStimuli)<-CNOlist$namesStimuli
  namesInhibitors<-setdiff(CNOlist$namesInhibitors, CNOlist$namesSignals)
  valueInhibitors<-CNOlist$valueInhibitors
  colnames(valueInhibitors)<-CNOlist$namesInhibitors
  valueInhibitors<-as.matrix(valueInhibitors[,namesInhibitors])
  colnames(valueInhibitors)<-namesInhibitors

  valueInhibitors<-1-valueInhibitors
  #valueInhibitors[valueInhibitors==1]<-NA
  
  valueSignals<-CNOlist$valueSignals[[2]]
  valueSignals[is.na(valueSignals)]<-0
  colnames(valueSignals)<-CNOlist$namesSignals
  dataset<-cbind(valueStimuli, valueInhibitors, valueSignals)

  mim<-build.mim(dataset=dataset)

  if (method=="ARACNE"){
    net<-aracne(mim, eps=0)
  }else if (method=="CLR"){
    net<-clr(mim)
  }
  
  graph<-as(net, "graphNEL")
  sif<-graph2sif(graph, writeSif=FALSE)
  
  # delete all links going to stimuli
  sif<-sif[-which(sif[,3]%in%CNOlist$namesStimuli),]
  
  # if a PKN is given as input, the directionality of the links is selected according to the PKN
  
  if (!is.null(PKNgraph)){
    ixRem<-vector()
    for (i in 1:dim(sif)[1]){
      node1<-sif[i,1]
      node2<-sif[i,3]
      ck<-SearchLinkGraph(node1,node2,PKNgraph)
      if (ck==1){
        oppLink<-intersect(which(sif[,1]==node2), which(sif[,3]==node1))
        if (length(oppLink)>0){
          #print(c(node1, node2))
          ixRem<-c(ixRem,oppLink)
        }
      }
    }
    if (length(ixRem>0)){sif<-sif[-ixRem,]}
  }
  
  
  write.table(sif, file=paste(filename,".sif",sep=""), row.names=FALSE,col.names=FALSE,quote=FALSE,sep="\t")

  return(sif)
}
