/* 
 * File:   newClass.h
 * Author: davidh
 *
 * Created on 23 March 2011, 14:07
 */

#ifndef NEWCLASS_H
#define	NEWCLASS_H

class newClass {
public:
    newClass();
    newClass(const newClass& orig);
    virtual ~newClass();
private:

};

#endif	/* NEWCLASS_H */

