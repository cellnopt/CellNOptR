library(CNelephanteR);
library(odeBooleanR);
setwd('testBoolean');
boolModel=readSif('Network.sif');
odeModel=createOdefyModel(boolModel$interMat,boolModel$notMat,boolModel$namesSpecies);
paramInfo=writeCfunction(odeModel)
